import fs from 'node:fs';
import vm from 'node:vm';

const html=fs.readFileSync('dist/index.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)?.[1];
if(!script)throw new Error('Uygulama betiği bulunamadı');

function classList(){
  const values=new Set();
  return {add:(...x)=>x.forEach(v=>values.add(v)),remove:(...x)=>x.forEach(v=>values.delete(v)),toggle:(v,f)=>f?values.add(v):values.delete(v),contains:v=>values.has(v)};
}

function element(id){
  const handlers={};
  return {
    id,value:'',checked:false,textContent:'',innerHTML:'',attrs:{},handlers,classList:classList(),
    addEventListener:(type,fn)=>{handlers[type]=fn},
    setAttribute(name,value){this.attrs[name]=String(value)},
    focus(){},scrollIntoView(){},
    querySelector(selector){
      if(selector==='.rtib-daily'&&this.innerHTML.includes('rtib-daily'))return {outerHTML:this.innerHTML};
      return null;
    }
  };
}

const ids=['issueTitle','issueCity','issueNo','agendaText','briefing','previewPanel','toast','webTab','emailTab','copyBtn','generateBtn','sampleBtn','emptyState','editorControl','newsManager','noLead','statEditor','statList','statAdd','fxDate','fxTry','fxEur','fxUsd','fxCny'];
const nodes=Object.fromEntries(ids.map(id=>[id,element(id)]));
Object.assign(nodes.issueTitle,{value:'RTİB Günlük Gündem'});
Object.assign(nodes.issueCity,{value:'Moskova'});
Object.assign(nodes.issueNo,{value:'Günlük'});
Object.assign(nodes.fxDate,{value:'17.09.2026'});
Object.assign(nodes.fxTry,{value:'1.7319'});
Object.assign(nodes.fxEur,{value:'97.1275'});
Object.assign(nodes.fxUsd,{value:'84.1732'});
Object.assign(nodes.fxCny,{value:'12.5457'});

const document={
  styleSheets:[],
  querySelector(selector){return nodes[selector.replace('#','')]||null},
  createElement(){let value='';return {set textContent(text){value=String(text)},get innerHTML(){return value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}}}
};
const storage=new Map();
const context={document,window:{innerWidth:1400},navigator:{clipboard:{writeText:async value=>storage.set('clipboard',value)}},localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)},setTimeout:fn=>{fn();return 1},clearTimeout(){},Date,JSON,console,Array,String,Set,Number};
vm.createContext(context);
vm.runInContext(script,context);

nodes.sampleBtn.handlers.click();
if(!nodes.editorControl.classList.contains('show'))throw new Error('Haber yönetimi açılmadı');
if(!nodes.newsManager.innerHTML.includes('data-move="up"'))throw new Error('Sıralama kontrolleri oluşmadı');
if(nodes.briefing.innerHTML.includes('Günün Ana Haberi'))throw new Error('Ana haber kullanıcı seçmeden atandı');
if(!nodes.briefing.innerHTML.includes('Resmî Döviz Kurları')||!nodes.briefing.innerHTML.includes('97.1275')||!nodes.briefing.innerHTML.includes('rtib-fx-icon'))throw new Error('İkonlu döviz kuru alanı oluşmadı');

nodes.newsManager.handlers.change({target:{closest:()=>({value:'news-0'})}});
if(!nodes.briefing.innerHTML.includes('Günün Ana Haberi'))throw new Error('Ana haber seçimi uygulanmadı');
if(!nodes.statEditor.classList.contains('show'))throw new Error('Veri kartı editörü açılmadı');
if(nodes.statList.innerHTML.includes('kritik gösterge'))throw new Error('Eski genel veri açıklaması kullanılıyor');

nodes.newsManager.handlers.click({target:{closest:()=>({dataset:{move:'up',id:'news-1'}})}});
if(nodes.newsManager.innerHTML.indexOf('news-1')>nodes.newsManager.innerHTML.indexOf('news-0'))throw new Error('Haber sıralaması değişmedi');

nodes.statList.handlers.input({target:{closest:()=>({dataset:{statIndex:'0',statField:'label'},value:'Günlük Brent petrol fiyatı'})}});
if(!nodes.briefing.innerHTML.includes('Günlük Brent petrol fiyatı'))throw new Error('Veri kartı açıklaması düzenlenmedi');

nodes.emailTab.handlers.click();
await nodes.copyBtn.handlers.click();
const email=storage.get('clipboard')||'';
if(!email.includes('RTİB FluentCRM')||!email.includes('Resmî Döviz Kurları')||!email.includes('ANA HABER'))throw new Error('E-posta çıktısı eksik');

if(!fs.existsSync('dist/assets/RTIB_yatay_logo.png'))throw new Error('Orijinal RTİB logosu eksik');
if(!fs.existsSync('dist/assets/erdem-acay.jpg'))throw new Error('Başkan görseli eksik');
if(!/@media\(max-width:680px\)/.test(html))throw new Error('Mobil görünüm kuralları eksik');

console.log(JSON.stringify({ok:true,manualLead:true,reordering:true,editableStats:true,exchangeRates:true,email:true,mobile:true}));
